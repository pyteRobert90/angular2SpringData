import { Component } from '@angular/core';
import { ROUTER_DIRECTIVES } from '@angular/router';
import {Config} from "./components/config/config";
import { ProductService } from './components/products/product.service';

@Component({
  selector: 'app',
  pipes: [],
  providers: [],
  directives: [ ROUTER_DIRECTIVES ],
  templateUrl: './app.html',
})
export class App {
  constructor(private _config:Config) {}

}

import {Http, Response} from "@angular/http";
import {Injectable, OnInit} from "@angular/core";

@Injectable()
export class Config{
  private _server: Object;
  constructor(private http: Http) {
    this.load(); //tralalasfsd aswfs
  }
  load()  {
    return new Promise((resolve, reject) => {
      this.http.get('/frontend/app/components/config/path.json')
       .map(res => res.json())
       .subscribe((server_data) => {
       this._server = server_data;

 });
 });
  }
  getServer() {
    return this._server[0].serverUrl;
  }

};

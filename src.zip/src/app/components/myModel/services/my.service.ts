import {Injectable, Inject} from '@angular/core';
import {Http, Response} from '@angular/http';
import {MyModel} from '../../../components/myModel/model/myModel';
import {Observable} from 'rxjs/Observable';
import 'rxjs/Rx';
import {Config} from "../../../components/config/config";

@Injectable()
export class MyService {

    private _backendUrl: string; // URL to web api
    constructor ( private http: Http,private _config:Config) {
      this._backendUrl=_config.getServer();
    }

    getModel(): Observable<MyModel[]> {
      var path=this._backendUrl+'/welcome';
        return this.http.get(path)
            .map((response:Response)=><MyModel[]> response.json())
            .catch(this.handleError);

    }


  private handleError (error: Response) {

        console.log(error);
        return Observable.throw(error.json().error || 'Server error');
    }
}

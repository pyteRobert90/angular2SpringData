export interface MyModel{


  message : string;



}

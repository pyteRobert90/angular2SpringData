import {Component} from '@angular/core';
@Component({
  selector:'myModelList',
  template:'Call'

})
export class MyModelList{}

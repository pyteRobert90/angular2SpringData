import { Component, OnInit,Inject }  from '@angular/core';
import { ROUTER_DIRECTIVES, RouterLink  } from '@angular/router';
import { IProduct } from './product';
import { ProductService } from './product.service';
import { TableSortableComponent } from './table-sortable.component';
import {HTTP_PROVIDERS} from "@angular/http";

@Component({
  templateUrl: './product-list.component.html',
  directives: [ROUTER_DIRECTIVES, TableSortableComponent],
  providers:  [HTTP_PROVIDERS, ProductService]
})
export class ProductListComponent implements OnInit {
  pageTitle: string = 'Product List';
  errorMessage: string;
  products: IProduct[];

  columns: any[] = [
    {
      display: 'Product', //The text to display
      variable: 'productName', //The name of the key that's apart of the data array
      filter: 'text' //The type data type of the column (number, text, date, etc.)
    },
    {
      display: 'Code', //The text to display
      variable: 'productCode', //The name of the key that's apart of the data array
      filter: 'text' //The type data type of the column (number, text, date, etc.)
    },
    {
      display: 'Available', //The text to display
      variable: 'releaseDate', //The name of the key that's apart of the data array
      filter: 'date' //The type data type of the column (number, text, date, etc.)
    },
    {
      display: 'Description',
      variable: 'description',
      filter: 'text'
    },
    {
      display: 'Price',
      variable: 'price',
      filter: 'number'
    }

  ];

  sorting: any = {
    column: 'productName', //to match the variable of one of the columns
    descending: false
  };

  constructor(@Inject(ProductService) public productService){
  }

  ngOnInit(): void {
    this.productService.getProducts()
      .subscribe((response) => {
          this.products = response;
          error => this.errorMessage = <any>error;
        }
      );
  }

}

import {  PipeTransform, Pipe } from '@angular/core';
import { IProduct } from './product';

@Pipe({
      name: 'productFilter',
      pure: false
})
export class ProductFilterPipe implements PipeTransform {

    transform(value: IProduct[], args: string[]): IProduct[] {

      let filter: string = args ? args.toString() : null;

      return filter ? value.filter((product: IProduct) =>
                product.productName.toLocaleLowerCase().indexOf(filter) !== -1) : value;
        }
}

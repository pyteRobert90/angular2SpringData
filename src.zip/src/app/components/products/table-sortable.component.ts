import { Component, Input } from '@angular/core';
import { OrderBy } from "./orderBy";
import { ProductFilterPipe } from './product-filter.pipe';
import {HTTP_PROVIDERS} from "@angular/http";
import {ProductService} from "./product.service";

@Component({
  selector: 'table-sortable',
  templateUrl: './products-table.html',
  pipes: [OrderBy, ProductFilterPipe],
  providers:  [HTTP_PROVIDERS, ProductService]

})
export class TableSortableComponent {

  listFilter:string = '';

  @Input() columns:any[];
  @Input() data:any[];
  @Input() sort:any;

  selectedClass(columnName):string {
    return columnName == this.sort.column ? 'sort-' + this.sort.descending : '';
  }

  changeSorting(columnName):void {
    var sort = this.sort;
    if (sort.column == columnName) {
      sort.descending = !sort.descending;
    } else {
      sort.column = columnName;
      sort.descending = false;
    }
  }

  convertSorting():string {
    return this.sort.descending ? '-' + this.sort.column : this.sort.column;
  }
}

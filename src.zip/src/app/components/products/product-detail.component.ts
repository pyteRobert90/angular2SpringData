import { Component, OnInit } from '@angular/core';
import { RouteParams, Router } from '@angular/router';

import { IProduct } from './product';
import { ProductService } from './product.service';

@Component({
	templateUrl: './product-detail.component.html'
})

export class ProductDetailComponent implements OnInit {
	
	pageTitle: string = 'Product Detail';
	product: IProduct;
	errorMessage: string;
	
	constructor(private _productService: ProductService, private _router: Router, private _routeParams: RouteParams) {
		
	}
	
	ngOnInit() {
		if(!this.product) {
			let id = +this._routeParams.get('id');
			this.getProduct(id);
		}
	}
	
	getProduct(id: number) {
		this._productService.getProduct(id).subscribe(product => this.product = product, error => this.errorMessage = <any> error);
	}
	
	onBack(): void {
		this._router.navigate(['Products']);
	}
}
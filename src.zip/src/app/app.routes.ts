import { provideRouter, RouterConfig } from '@angular/router';

import {About} from './components/about/about';
import {Home} from './components/home/home';
import {MyModelPage} from './components/myModel/myModelPage';
import {ProductListComponent} from './components/products/product-list.component';
import {TableDemoComponent} from "./components/table/table-demo-component";
import {ProductDetailComponent} from "./components/products/product-detail.component";

const routes: RouterConfig = [
  { path: '', redirectTo: 'home', terminal: true },
  { path: 'home', component: Home },
  { path: 'about', component: About },
  { path: 'myModel', component: MyModelPage },
  { path: 'products', component: ProductListComponent },
  { path: 'table', component:TableDemoComponent },
  { path: 'productDetail/:id', component: ProductDetailComponent }
];

export const APP_ROUTER_PROVIDERS = [
  provideRouter(routes)
];

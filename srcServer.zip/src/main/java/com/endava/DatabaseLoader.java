package com.endava;

import com.endava.model.MyModel;
import com.endava.model.ProductModel;
import com.endava.repository.ModelRepository;
import com.endava.repository.ProductRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.util.Date;
import java.lang.*;

/**
 * Created by rmilitaru on 7/6/2016.
 */
@Component
public class DatabaseLoader implements CommandLineRunner {

    private final ModelRepository repository;
    
    private final ProductRepository productRepository;

    @Autowired
    public DatabaseLoader(ModelRepository repository, ProductRepository productRepository) {
        this.repository = repository;
        this.productRepository = productRepository;
    }

    @Override
    public void run(String... strings) throws Exception {
        this.repository.save(new MyModel("Message from database",1L));
        this.repository.save(new MyModel("Other message from database",2L));
        
        
        this.productRepository.save(new ProductModel(1L, "product name", "product code", "description", new Date(), new Double(12.2)));
        
        
    }
}
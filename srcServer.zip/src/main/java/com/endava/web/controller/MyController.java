package com.endava.web.controller;

import com.endava.model.MyModel;
import com.endava.model.ProductModel;
import java.util.Date;

import com.endava.repository.ModelRepository;
import com.endava.repository.ProductRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by rmilitaru on 7/5/2016.
 */

@RestController
public class MyController {

    @Autowired
    private ModelRepository repository;
    
    @Autowired
    private ProductRepository productRepository;

    @RequestMapping(value = "/welcome", method = RequestMethod.GET)
    public @ResponseBody List<MyModel> getDummy(){

        List<MyModel> myModels= (List<MyModel>) repository.findAll();


        return myModels;
    }
    
    @RequestMapping(value = "/products", method = RequestMethod.GET)
    public @ResponseBody List<ProductModel> getProducts(){

        List<ProductModel> products= (List<ProductModel>) productRepository.findAll();
        return products;
    }

}

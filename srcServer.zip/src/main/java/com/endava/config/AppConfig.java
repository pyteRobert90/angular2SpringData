//package com.endava.config;
//import static org.hibernate.cfg.AvailableSettings.HBM2DDL_AUTO;
//
//import java.util.Hashtable;
//import java.util.Map;
//import java.util.Properties;
//import java.util.logging.Logger;
//
//import javax.naming.Context;
//import javax.naming.InitialContext;
//import javax.naming.NamingException;
//import javax.persistence.SharedCacheMode;
//import javax.persistence.ValidationMode;
//import javax.sql.DataSource;
//
//import org.hibernate.annotations.common.util.impl.LoggerFactory;
//import org.springframework.context.annotation.*;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//
//import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
//import org.springframework.jndi.JndiObjectFactoryBean;
//import org.springframework.orm.jpa.*;
//import org.springframework.orm.jpa.vendor.*;
//import org.springframework.transaction.PlatformTransactionManager;
//
//
//@Configuration
//@EnableJpaRepositories(basePackages = { "com.endava.repository" })
//public class AppConfig  {
//
//    private static final org.slf4j.Logger log= org.slf4j.LoggerFactory.getLogger(AppConfig.class);
//    @Bean
//    public DataSource dataSource() {
//        JndiDataSourceLookup  jndiObjectFactoryBean= new JndiDataSourceLookup();
//        jndiObjectFactoryBean.setResourceRef(true);
//        DataSource dataSource=jndiObjectFactoryBean.getDataSource("Angular2");
//        return dataSource;
//
//    }
//
//    @Bean
//    public JpaVendorAdapter jpaVendorAdapter() {
//        HibernateJpaVendorAdapter adapter = new HibernateJpaVendorAdapter();
//        adapter.setShowSql(true);
//        adapter.setGenerateDdl(true);
//        adapter.setDatabase(Database.ORACLE);
//        return adapter;
//    }
//
//    @Bean
//    public org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean entityManagerFactory() throws ClassNotFoundException {
//        org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean factoryBean = new LocalContainerEntityManagerFactoryBean();
//        factoryBean.setDataSource(this.dataSource());
//        factoryBean.setPackagesToScan("com.endava.model");
//        factoryBean.setJpaVendorAdapter(jpaVendorAdapter());
//        factoryBean.setJpaProperties(jpaProperties());
//
//        return factoryBean;
//    }
//
//    @Bean
//    public JpaTransactionManager transactionManager() throws ClassNotFoundException {
//        JpaTransactionManager transactionManager = new JpaTransactionManager();
//        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
//
//        return transactionManager;
//    }
//
//    @Bean
//    public Properties jpaProperties() {
//        Properties properties = new Properties();
//        properties.put(HBM2DDL_AUTO, "create-drop");
//        return properties;
//    }
//
//}
package com.endava.repository;

import com.endava.model.ProductModel;
import org.springframework.data.repository.CrudRepository;


public interface ProductRepository  extends CrudRepository<ProductModel, Long> {

}
package com.endava.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.util.Date;

@Data
@Entity
public class ProductModel {

    private @Id
    @GeneratedValue Long id;

    private String productName;
    
    private String productCode;
    
    private String description;
    
    private Date releaseDate;
    
    private Double price;
    
    public ProductModel() {
    }

    public ProductModel(Long id, String productName, String productCode, String description, Date releaseDate, Double price) {
        this.id = id;
        this.productName = productName;
        this.productCode = productCode;
        this.description = description;
        this.releaseDate = releaseDate;
        this.price = price;
    }


    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
    
    public String getProductCode() {
    	return productCode;
    }
    
    public void setProductCode(String productCode){
    	this.productCode = productCode;
    }
    
    public String getDescription() {
    	return description;
    }
    
    public void setDescription(String description){
    	this.description = description;
    }
    
    public Date getReleaseDate(){
    	return releaseDate;
    }
    
    public void setReleaseDate(Date releaseDate){
    	this.releaseDate = releaseDate;
    }
    
    public Double getPrice(){
    	return price;
    }
    
    public void setPrice(Double price){
    	this.price = price;
    }
}
